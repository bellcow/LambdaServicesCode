const AWS = require('aws-sdk');
const DynamoDB = new AWS.DynamoDB.DocumentClient({region: 'us-east-1', apiVersion: '2012-08-10'});
var SquareConnect = require('square-connect');
var uuid = require('uuid');
var defaultClient = SquareConnect.ApiClient.instance;
var oauth2 = defaultClient.authentications['oauth2'];
//oauth2.accessToken = "EAAAENT3rhcU0U3LbKeC5-KCdam3nn8hS70G5_UU4C9PgI5Ap4yCvEtxXCMheSAP";
var checkoutApiInstance = new SquareConnect.CheckoutApi();
//var locationKey = "CBASEABfsrGxoGCjOYsah4779D8gAQ";
let locationKey = "";

exports.handler = (data, context, callback) => {
    console.log('----data---',data);
    if(!data) {
        context.done(null, {"success":false, "message":"Invalid parameters"});
    } else if(!data.appname){
		context.done(null, {"success":false, "message":"appname is null"});
	} else if(data.appname){
		
		console.log('appname ---', data.appname);
		
		var params = {
			TableName: 'sqaure_apps',
			Key: {
				"appname" : data.appname
			}
		}
		
		DynamoDB.get(params, function(err, data_1){
			
			console.log('database fetch for appname is ', data_1);
			
			if(err){
				console.log('error while reading the appname', appname);
				callback(err, null);
			} else{
				console.log('getting data for the params : ', params);
				oauth2.accessToken = data_1.Item.accessToken;
				locationKey = data_1.Item.locationKey;
				console.log('locationKey is  ', locationKey);
				console.log('accessToken is  ', data_1.Item.accessToken);	


								
					let orderData = data.orderInfo;
					let referenceId = 'order_'+Date.now().toString();
				  
					orderData.idempotency_key = uuid.v1();
					orderData.order.reference_id = referenceId;
					


					return checkoutApiInstance.createCheckout(locationKey, orderData).then(async function(checkoutRes) {
						console.log('----success------', checkoutRes);
						let dbObj = {};
						dbObj["orderId"] = referenceId;
						dbObj["transactionId"] = referenceId;
						dbObj['line_items'] = orderData.order.line_items;
						dbObj['discounts'] = orderData.order.discounts ;
						dbObj['taxes'] = orderData.order.taxes;
						dbObj['paymentStatus'] = 'Pending';
						dbObj['name'] = data.name;
						dbObj['email'] = data.email;
						dbObj['phone'] = data.phone;
						dbObj["dateAdded"] = (new Date().getMonth()+1).toString()+'-'+(new Date().getDate()-1).toString()+'-'+ new Date().getFullYear().toString();
						dbObj["squareResponse"] = checkoutRes;
						dbObj["appname"] = data.appname;
						const params = {
						  Item : dbObj,
						  TableName : "square_payments"
						};
						
						let putItem = new Promise((res, rej) => {
							console.log('params', params);
							DynamoDB.put(params, async (err, data) => {
							   if(err) {
								  console.log("Error in storing data :: " + err);
								  rej({"success":false,"message":"Failed to store order info"});
							   } else{
								  console.log("successfully added to database about "+ data);
								  let emailRes = await sendEmailNotification();
								  res(checkoutRes);
							   }
							});
						});
						
						const result = await putItem;
						console.log('returning square response to UI', checkoutRes);
						//return checkoutRes;
						callback(null, buildResponse(checkoutRes));
						
						
						
								function buildResponse(res){
									
									return {
										"checkoutPageUrl" : res.checkout.checkout_page_url,
										"referenceId" : res.checkout.order.reference_id,
										"transactionId" : res.checkout.order.id,
										"message" : "paymentCreated"
									}
								}
						
						
							    async function sendEmailNotification() {
								return new Promise(async function(resolve,reject) {
									try {
										console.log('came to mail');
										const danceHtmlBody = `
											<!DOCTYPE html>
											<html>
											  <head>
											  </head>
											  <body>
												<p> Hey Guys, Here is another partner is trying to register for classes. Payment not yet completed.</p>
												<p> Order Reference : ${referenceId} </p>
												<p> Order Details : ${JSON.stringify(orderData.order.line_items)} </p>
												<p> Name : ${data.name} </p>
												<p> Email : ${data.email} </p>
												<p> Phone : ${data.phone} </p>
											  </body>
											</html>
										`;
										const danceTextBody = ` Hi Guys,...`;
										const danceEmailParams = {
											Destination: {
											  ToAddresses: ['dlamb@bellcoww.com']    // 'info@artismotion.org'
											},
											Message: {
											  Body: {
												Html: {
												  Charset: "UTF-8",
												  Data: danceHtmlBody
												},
												Text: {
												  Charset: "UTF-8",
												  Data: danceTextBody
												}
											  },
											  Subject: {
												Charset: "UTF-8",
												Data: "New client payment initialized"
											  }
											},
											Source: "New client is trying to register for classes <dlamb@bellcoww.com>"
										};
										const danceSendPromise = new AWS.SES({ apiVersion: "2010-12-01" }).sendEmail(danceEmailParams).promise();
										danceSendPromise.then(data => {
										  console.log('dance email response', data);
										  return resolve({"success":true,"message":"Thanks for Contacting Artismotion! We will reach you soon.."});
										}).catch(err => {
										  console.error(err, err.stack);
										  return resolve({"success":false,"message":"Failed to send email notification"});
										});
									} catch(err) {
										console.log(err);
										return resolve({"success":false,"message":"Failed to send email notification"});
									}
								});
							}
						
						
						
						
						
					}, function(error) {
						console.error('----error------',error);
						callback(error,null);
					});
				
			}
		});
	}
	
	
	
	

};
