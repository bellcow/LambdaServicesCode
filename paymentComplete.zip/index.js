const AWS = require('aws-sdk');
const DynamoDB = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1', apiVersion: '2012-08-10' });
const s3 = new AWS.S3({region:'us-east-1',apiVersion:'2006-03-01'});
const docClient = new AWS.DynamoDB.DocumentClient();
const Handlebars = require('handlebars');
var clientTemplate = '';
var userTemplate = '';
var appname = '';
var appInfo;

function loadPaymentInformation(referenceId) {

    return new Promise((resolve, reject) => {

        const params = {
            TableName: 'square_payments',
            KeyConditionExpression: "#orderId = :orderId",
            ExpressionAttributeNames: {
                "#orderId": "orderId"
            },
            ExpressionAttributeValues: {
                ":orderId": referenceId
            }
        };
        console.log('Message : params for getting square details ', params);

        docClient.query(params, function (err, data) {
            if (err) {
                console.error("ErrorMessage : Unable to query. Error:", JSON.stringify(err, null, 2));
                reject(false);
            } else {
                console.log("Message : loaded data is ", data.Items[0]);
                resolve(data.Items[0]);
            }

        });

    });

}


async function sendEmailNotificationVendor(paymentInfo, referenceId) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log('came to mail');
            let subtotal = 0;
            let orderObj = [];
            let items = paymentInfo.line_items;
            for (let i = 0; i < items.length; i++) {
                subtotal += items[i].base_price_money.amount;
                orderObj.push({ name: items[i].name, description: '', price: items[i].base_price_money.amount, quantity: items[i].quantity });
            }
            let clientTemplateData = {  //FOR FINAL TEMPLATE (NOT FOR TESTING)
                adminName: appInfo.adminName,
                body_line_1: `Here is another user trying to register for classes.`,
                body_line_2:'Payment is successful!',
                referenceId: referenceId,
                name: paymentInfo.name,
                email: paymentInfo.email,
                phone: paymentInfo.phone,
                comments: paymentInfo.comments ? paymentInfo.comments : 'None',
                nunmberOfItems: items.length.toString(),
                subtotal: subtotal,
                tax: 0,
                discount: 0,
                orderTotal: 0,
                orders: orderObj
            };
            clientTemplateData["orderTotal"] = subtotal - clientTemplateData.discount + clientTemplateData.tax;

        
            const danceTextBody = ` Hi Team,...`;
            const danceEmailParams = {
                Destination: {
                    ToAddresses: [appInfo.adminEmailId]    // 'info@artismotion.org'
                },
                Message: {
                    Body: {
                        Html: {
                            Charset: "UTF-8",
                            Data: clientTemplate(clientTemplateData)
                        },
                        Text: {
                            Charset: "UTF-8",
                            Data: danceTextBody
                        }
                    },
                    Subject: {
                        Charset: "UTF-8",
                        Data: "New client is registered successfully."
                    }
                },
                Source: "New partner is registered successfully <dlamb@bellcoww.com>"
            };
            const danceSendPromise = new AWS.SES({ apiVersion: "2010-12-01" }).sendEmail(danceEmailParams).promise();
            danceSendPromise.then(data => {
                console.log('dance email response', data);
                return resolve({ "success": true, "message": "Thanks for the registration.", "orderDetails": paymentInfo });
            }).catch(err => {
                console.error(err, err.stack);
                return resolve({ "success": false, "message": "Failed to send email notification" });
            });
        } catch (err) {
            console.log(err);
            return resolve({ "success": false, "message": "Failed to send email notification" });
        }
    });
}


async function sendEmailNotificationUser(paymentInfo, referenceId) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log('came to mail User');
            let items = paymentInfo.line_items;
            let subtotal = 0;
            let orderObj = [];
            for (let i = 0; i < items.length; i++) {
                subtotal += items[i].base_price_money.amount;
                orderObj.push({ name: items[i].name, description: '', price: items[i].base_price_money.amount, quantity: items[i].quantity });
            }
            let templateData = {  //FOR FINAL TEMPLATE (NOT FOR TESTING)
                name: paymentInfo.name,
                nunmberOfItems: items.length.toString(),
                subtotal: subtotal,
                tax: 0,
                discount: 0,
                orderTotal: 0,
                orders: orderObj
            };
            templateData["orderTotal"] = subtotal - templateData.discount + templateData.tax;
            const danceTextBody = ` Hi there,...`;
            const danceEmailParams = {
                Destination: {
                    ToAddresses: [paymentInfo.email]    // 'info@artismotion.org'
                },
                Message: {
                    Body: {
                        Html: {
                            Charset: "UTF-8",
                            Data: userTemplate(templateData)
                        },
                        Text: {
                            Charset: "UTF-8",
                            Data: danceTextBody
                        }
                    },
                    Subject: {
                        Charset: "UTF-8",
                        Data: "Art is motion order Confirmed"
                    }
                },
                Source: "Thankyou! Art Is Motion <info@artismotion.org>"
            };
            const danceSendPromise = new AWS.SES({ apiVersion: "2010-12-01" }).sendEmail(danceEmailParams).promise();
            danceSendPromise.then(data => {
                console.log('dance email response', data);
                return resolve({ "success": true, "message": "Thanks for the registration." });
            }).catch(err => {
                console.error(err, err.stack);
                return resolve({ "success": false, "message": "Failed to send email notification" });
            });
        } catch (err) {
            console.log(err);
            return resolve({ "success": false, "message": "Failed to send email notification" });
        }
    });
}



function updateDatabase(referenceId, transactionId, paymentInfo) {
    return new Promise((resolve, reject) => {

        const params = {
            Key: { "orderId": referenceId },
            TableName: "square_payments",
            UpdateExpression: "set paymentStatus = :paymentStatus, transactionId = :transactionId",
            ExpressionAttributeValues: {
                ":paymentStatus": 'Completed',
                ":transactionId": transactionId
            },
            ReturnValues: "UPDATED_NEW"
        };

        let updateItem = new Promise((res, rej) => {
            console.log('params', params);
            DynamoDB.update(params, async (err, data) => {
                if (err) {
                    console.log("Error in storing data :: " + err);
                    rej({ "success": false, "message": "Failed to store order info" });
                } else {
                    console.log("successfully updated to database about " + data);
                    let emailRes = await sendEmailNotificationVendor(paymentInfo, referenceId);
                    console.log("Message : vendor email response ", emailRes);
                    if (emailRes.success === true) {
                        console.log("Message : now sending email notification for client regrading payment confirmation", referenceId)
                        emailRes = await sendEmailNotificationUser(paymentInfo, referenceId);
                    }
                    res(emailRes);
                }
            });
        });

        resolve(updateItem);
    });



}

exports.handler = async (data, context, callback) => {
    //data = JSON.parse(data.body);
    console.log('Message : data is ', data);
    if (!data) {
        context.done(null, { "success": false, "message": "Invalid parameters" });
    } else if (!data.appname) {
        context.done(null, { "success": false, "message": "Missing appname" });
    }
    appname = data.appname;
    let referenceId = data.referenceId;
    const paymentInfo = await loadPaymentInformation(referenceId);
    await loadTemplates();
    appInfo = await loadAppInfo(appname);
    if(!appInfo){
        context.done(null,{"Message":"app with given appname not found"});
    }
    console.log("Message : db details for the payments is ", paymentInfo);

    let transactionId = paymentInfo.transactionId;

    if (paymentInfo === undefined) {
        console.error("Message : payment information not found");
        context.done(null, { "success": false, "message": "reference ID not found" });
    } else if (paymentInfo.paymentStatus === 'Completed') {
        console.log("Message : payment information already done");
        context.done(null, { "success": true, "message": "payment is already done", "orderDetails": paymentInfo.line_items });
    } else {
        console.log("Message : updating db and sending notifications", referenceId)
        const responseEmail = await updateDatabase(referenceId, transactionId, paymentInfo);

        if (responseEmail.success === true) {
            context.done(null, { "success": true, "message": "payment successful", "orderDetails": paymentInfo.line_items });
        }

    }

    

};

function loadAppInfo(appname) {

    return new Promise(function (resolve, reject) {

        const params = {
            TableName: 'apps_info',
            KeyConditionExpression: "#ap = :appname",
            ExpressionAttributeNames: {
                "#ap": "appname"
            },
            ExpressionAttributeValues: {
                ":appname": appname
            }
        };

        console.log('Message : params for getting recaptcha secret', params);

        docClient.query(params, function (err, data) {
            if (err) {
                console.error("ErrorMessage : Unable to query. Error:", JSON.stringify(err, null, 2));
            } else {
                console.log("Message : loaded recaptcha secret is ", data.Items[0].recaptchaSecret)
                resolve(data.Items[0]);
            }

        });
    });
}

function loadTemplates(){
    return new Promise((resolve,reject)=>{
        let templateParams = {
            Bucket:'bellcoww-mail-templates',
            Key:'artismotion/payment-create-complete-template.json'
        };
        s3.getObject(templateParams,(err,s3Data)=>{
            if(err){
                console.log(err);
                eventBus.emit('err',{error:true, s3Error: err});
            }else{
               clientTemplate = Handlebars.compile(JSON.parse(s3Data.Body.toString()).client_html);
               userTemplate = Handlebars.compile(JSON.parse(s3Data.Body.toString()).user_html);
               resolve();
            }
        });
    });
}