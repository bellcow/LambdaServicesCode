const AWS = require('aws-sdk');
const https = require('https');
const dynamoDb = new AWS.DynamoDB({
    region: 'us-east-1',
    apiVersion: '2012-08-10'
});
const events = require('events');
const docClient = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3({ region: 'us-east-1', apiVersion: '2006-03-01' });
const Handlebars = require('handlebars');
var clientTemplate = '';
var userTemplate = '';
var appname = '';
var apitype = '';
var a_location = '';
var eventBus = new events.EventEmitter();
var appInfo;
var dbObj = {};
function recaptchaVerification(recaptcha, recaptchaSecretValue) {

    return new Promise((resolve, reject) => {

        console.log('Message : recaptcha value is ', recaptcha);
        console.log('Message : recaptchaSecret value is ', recaptchaSecretValue);
        const querystring = require('querystring');
        const postData = querystring.stringify({
            secret: recaptchaSecretValue,
            response: recaptcha
        });
        console.log('Message : postdata for recaptcha : ', postData);
        var options = {
            hostname: 'www.google.com',
            path: '/recaptcha/api/siteverify',
            method: 'POST',
            port: 443,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }

        };

        var req = https.request(options, (res) => {

            res.on('data', (d) => {
                if (d === undefined) {
                    console.log('Message : Error is ', d);
                    reject(false);
                }

                const response = JSON.parse(d);
                console.log('Message : response from recaptcha ', response);
                if (response.success === true) {
                    console.log('Message : recaptcha response is success');
                    resolve(true);
                } else {
                    console.log('Message : recaptcha response is failed');
                    reject(false);



                }
            })
        });
        req.write(postData);
        req.end();


    })
}




exports.handler = async (event, context, callback) => {

    console.log("Message : Here is the requst body :  ", event);
    console.log('\n headers : ');
    console.log(event);
    let headers = event.headers;
    event = event.body;
    let a_date = '';
    let a_time = '';
    console.log(headers);
    try {
        console.log('checking for appname ...')
        appname = headers["x-appname"];
    }
    catch (err) {
        console.log("error in appname try block");
        appname = undefined;
    }

    try {
        apitype = headers["x-apitype"];
        a_date = event["appointment_date"];
        a_time = event["appointment_time"];
        a_location = event["appointment_location"];
    }
    catch (err) {
        console.log('apitype missing');
    }
    if (apitype == undefined) {
        callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: "x-apitype header missing!" }) });
    }
    else {
        if (apitype == 'appointment') {
            if (a_date == undefined) {
                callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: "appointment date cannot be empty!" }) });
                return;
            }
            else if (a_time == undefined) {
                callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: "appointment time cannot be empty!" }) });
                return;
            }
        }

        //checking for appname header


        if (appname != null) {
            console.log('Message : appname is ', appname);


            appInfo = await loadAppInfo(appname);
            console.log("Message : recaptcha secret is ", appInfo);
            if (appInfo.recaptchaEnabled) {
                let reCaptchaResponse = await recaptchaVerification(event.recaptcha, appInfo.recaptchaSecret);
                console.log("Message : recaptcha response is ", reCaptchaResponse);
                if (!reCaptchaResponse) {
                    console.log("Message : recaptcha failed");
                    callback(null, buildChatResponse("recaptcha failed", 'failed'))
                }
            }

            if (!event.emailId.match(/^[^@]+@[^@]+$/)) {
                console.log("ErrorMessage : invalid email address", event);
                context.done(null, buildChatResponse("Invalid email id ", 'failed'));
                return;
            }


            let fields = ["firstName", "lastName", "emailId", "phoneNumber",
                "message", "localTime", "location", "ipAddress", "browserType",
                "browserVersion", "siteUrl", "referedFrom", "operatingSystem",
                "Platform", "scheme", "pageTitle", "latitude", "longitude", "localTimeZone", "screenResolution"];
            if (apitype == 'appointment') {
                fields.push("appointment_date");
                fields.push("appointment_time");
                fields.push("appointment_location");
            }
            

            dbObj["contactId"] = {
                S: appname + "_" + Date.now().toString()
            };

            console.log("Message : contact id is ", dbObj["contactId"]);
            console.log("Message : parameters from event", event);


            for (let i = 0; i < fields.length; i++) {
                if ((fields[i] in event && event[fields[i]]))
                    console.log("Message : adding into the data base : " + fields[i]);
                if (event[fields[i]] != null) {
                    dbObj[fields[i]] = {
                        S: event[fields[i]] ? event[fields[i]] : ''
                    }
                }
            }
            if(dbObj["appointment_location"].S == ''){
                dbObj["appointment_location"].S = appInfo.location;
            }
            dbObj["dateAdded"] = {
                S: (new Date().getMonth() + 1).toString() + '-' + (new Date().getDate() - 1).toString() + '-' + new Date().getFullYear().toString()
            };

            dbObj["timeAdded"] = {
                S: ((new Date()).toJSON().slice(0, 19).replace(/[-T]/g, ':'))
            };

            dbObj["appname"] = {
                S: appname
            };

            dbObj["apitype"] = {
                S: apitype
            };

            const params = {
                Item: dbObj,
                TableName: "bellcoww_contactus_table"
            };
            console.log("Message : adding data to table ", params);
            const parameters = event;
            console.log("Message : parameters are ", parameters);

            var name = parameters['firstname'] ? parameters['firstname'] : '' + ' ' + parameters['lastname'] ? parameters['lastname'] : '';
            console.log("full name is ", name);
            var emailId = parameters['emailId'];
            var phoneNumber = parameters['phoneNumber'];
            var message = parameters['message'];

            //This method is for writing into database
            dynamoDb.putItem(params, function (err, data) {
                console.log("Message : inside putItem method with params : ", params);
                if (err) {
                    console.log("Error in storing data :: " + err);
                    callback(err)
                } else {
                    console.log("successfully added to database about " + data);


                    //FETCHING TEMPLATES

                    let templateParams = {
                        Bucket: 'bellcoww-mail-templates',
                        Key: apitype=='contactus'? appInfo.contactMailTemplate:appInfo.appointmentMailTemplate
                    };
                    s3.getObject(templateParams, (err, s3Data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            clientTemplate = Handlebars.compile(JSON.parse(s3Data.Body.toString()).clientTemplate);
                            userTemplate = Handlebars.compile(JSON.parse(s3Data.Body.toString()).userTemplate);
                            console.log("Message : admin emailId is ", appInfo.adminEmailId);
                            sendEmailNotification(name, emailId, phoneNumber, message, appInfo.adminEmailId,
                                appInfo.contactUsUserEmailSource,apitype == 'appointment'? appInfo.appointmentUserEmailSubject:appInfo.contactUsUserEmailSubject,
                                appInfo.contactUsClientEmailSource, apitype == 'appointment'?appInfo.appointmentClientEmailSubject:appInfo.contactUsClientEmailSubject, appInfo.adminName);
                        }
                    });



                }
            });

            console.log("Message : Added contact into database");

            callback(null, { statusCode: 200, body: JSON.stringify({ success: true, message: "mails sent successfully!" }) });

        }
        else {
            callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: "Missing x-appname header" }) });
            console.log("missing x-appname header");
            console.log(err);
        }
        eventBus.on('err', (msg) => {
            console.log("event bus error called");
            callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: msg }) });
        });
    }

    function loadAppInfo(appname) {

        return new Promise(function (resolve, reject) {

            const params = {
                TableName: 'apps_info',
                KeyConditionExpression: "#ap = :appname",
                ExpressionAttributeNames: {
                    "#ap": "appname"
                },
                ExpressionAttributeValues: {
                    ":appname": appname
                }
            };

            console.log('Message : params for getting recaptcha secret', params);

            docClient.query(params, function (err, data) {
                if (err) {
                    console.error("ErrorMessage : Unable to query. Error:", JSON.stringify(err, null, 2));
                } else {
                    if (data.Items[0]) {
                        console.log("Message : loaded recaptcha secret is ", data.Items[0].recaptchaSecret)
                        resolve(data.Items[0]);
                    }
                    else {
                        console.log("appname not found!");
                        callback(null, { statusCode: 200, body: JSON.stringify({ success: false, message: "app not found!" }) });
                    }

                }

            });
        });
    }

};




//sending response
function buildChatResponse(chat, message) {
    return {

        "speech": chat,
        "displayText": chat,
        "message": message


    };

}

//this method is for email sending
function sendEmailNotification(name, emailId, phoneNumber, message, fromEmailId, userEmailSource, userEmailSubject, clientEmailSource, clientEmailSubject, adminName) {
    name = name.substr(0, 40).replace(/[^\w\s]/g, '');
    let clientHtmlBody = '';
    let userHtmlBody = '';
    if(apitype == 'contactus'){
        clientHtmlBody = clientTemplate({ name: name, emailId: emailId, phoneNumber: phoneNumber, message: message ? message : '', adminName: adminName });
        userHtmlBody = userTemplate({ name: name });
    } else{
        clientHtmlBody = clientTemplate({ name: name, emailId: emailId, phoneNumber: phoneNumber == ''?'Not specified':phoneNumber,time:dbObj["appointment_time"].S,date:dbObj["appointment_date"].S,location:dbObj["appointment_location"].S , adminName: adminName });
        userHtmlBody = userTemplate({ name: name, time:dbObj["appointment_time"].S,date:dbObj["appointment_date"].S,location:dbObj["appointment_location"].S});
    }

    const clientTextBody = ` Hi Guys,...`;
    const userTextBody = ` Hi ${name},...`;


    const userEmailParams = {
        Destination: {
            ToAddresses: [emailId]
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: userHtmlBody
                },
                Text: {
                    Charset: "UTF-8",
                    Data: userTextBody
                }
            },
            Subject: {
                Charset: "UTF-8",
                Data: 'Hello '+name+'! '+userEmailSubject
            }
        },
        Source: userEmailSource
    };

    const clientEmailParams = {
        Destination: {
            ToAddresses: [appInfo.adminEmailId] //    fromEmailId 'info@artismotion.org'
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: clientHtmlBody
                },
                Text: {
                    Charset: "UTF-8",
                    Data: clientTextBody
                }
            },
            Subject: {
                Charset: "UTF-8",
                Data: clientEmailSubject
            }
        },
        Source: clientEmailSource
    };

    //Create the promise and SES service object
    console.log("Message : Sending email", userEmailParams);
    const userSendPromise = new AWS.SES({
        apiVersion: "2010-12-01"
    }).sendEmail(userEmailParams).promise();
    console.log("Message : sending email", clientEmailParams);
    const clientSendPromise = new AWS.SES({
        apiVersion: "2010-12-01"
    }).sendEmail(clientEmailParams).promise();

    // Handle promise's fulfilled/rejected states

    clientSendPromise.then(data => {
        console.log(data.MessageId);

    }).catch(err => {
        console.error(err, err.stack);

    });
    userSendPromise.then(data => {
        console.log(data.MessageId);
        // context.done(null, {
        //    "success": true,
        //    "message": "Thanks for Contacting Art is Motion! We will reach you soon.."
        // });
    }).catch(err => {
        console.error(err, err.stack);
        //  context.done(null, {
        //      "success": false,
        //      "message": "Failed to send email notification"
        //  });
    })

}

