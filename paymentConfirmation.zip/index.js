const AWS = require("aws-sdk");
const DynamoDB = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1', apiVersion: '2012-08-10' });
const events = require('events');
const Handlebars = require('handlebars');
var artIsMotionOrders = '';
// const config = require('./config.json');
const s3 = new AWS.S3({region:'us-east-1',apiVersion:'2006-03-01'});

var eventBus = new events.EventEmitter();

// AWS.config.loadFromPath('./config.json');

function getOrderData(referenceId,email) {
    console.log('\nlog from getOrderData\n');
    let params = {
        TableName: "square_payments",
        KeyConditionExpression: "#orderId = :orderId",
        ExpressionAttributeNames: {
            "#orderId": "orderId"
        },
        ExpressionAttributeValues: {
            ":orderId": referenceId
        }
    }
    DynamoDB.query(params, (err, data) => {
        if (err) {
            console.log('\n db error:' + JSON.stringify(err) + '\n');
            eventBus.emit('err', {error:true, dbError: err });
        } else {
            if (data.Items[0] == undefined) {
                eventBus.emit('error',{error:true,dbError:"invalid order id"});
            } else {
                console.log('\n email:' + data.Items[0].email + '\n');
                console.log(data.Items[0]);

                //FETCHING TEMPLATE
                let templateParams = {
                    Bucket:'bellcoww-mail-templates',
                    Key:'artismotion/artismotion_payment_confirmation.json'
                };
                s3.getObject(templateParams,(err,s3Data)=>{
                    if(err){
                        console.log(err);
                        eventBus.emit('err',{error:true, s3Error: err});
                    }else{
                       artIsMotionOrders =  Handlebars.compile(JSON.parse(s3Data.Body.toString()).art_is_motion_orders);
                       sendEmailNotification(email == ''?data.Items[0].email:email, data.Items[0].name, data.Items[0].line_items);
                    }
                });

            }
        }
    });
}

function sendEmailNotification(mail, name, items) {
    console.log('\nlog from sendEmailNotification\n');
    let subtotal = 0;
    let orderObj = [];
    for(let i = 0; i < items.length; i++){
        subtotal += items[i].base_price_money.amount;
        orderObj.push({name:items[i].name,description:'',price:items[i].base_price_money.amount,quantity:items[i].quantity});
    }
    let templateData = {  //FOR FINAL TEMPLATE (NOT FOR TESTING)
        name:name,
        nunmberOfItems:items.length.toString(),
        subtotal:subtotal,
        tax:0,
        discount:0,
        orderTotal:0,
        orders:orderObj
    };
    templateData["orderTotal"] = subtotal - templateData.discount + templateData.tax;
    
    const params = {
        Destination: {
            ToAddresses: [mail] // 'info@artismotion.org'
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: artIsMotionOrders(templateData)
                },
            },
            Subject: {
                Charset: "UTF-8",
                Data: "Payment Confirmation"
            }
        },
        Source: "<dlamb@bellcoww.com>"
    };
    let sendMailPromise = new AWS.SES({ apiVersion: '2010-12-01' }).sendEmail(params).promise();
    sendMailPromise.then((data) => {
        console.log('\nemail data:\n');
        console.log(data);
        eventBus.emit('success');
    }).catch((err) => {
        console.log('\nemail error:' + err + '\n');
        eventBus.emit('err', {error:true, mailError: err });

    });
}

function getAppData(appname,orderId,email){
    let params = {
        TableName: "apps_info",
        KeyConditionExpression: "#appname = :appname",
        ExpressionAttributeNames: {
            "#appname": "appname"
        },
        ExpressionAttributeValues: {
            ":appname": appname
        }
    };

    DynamoDB.query(params,(err,data)=>{
        if(err){
            console.log('app_info db error');
            console.log(err);
            eventBus.emit('err',{error:true,dbError:err});
        }else{
            if(data.Items[0] == undefined){
                eventBus.emit('err',{error:true,appnameError:'app not found'});
            } else{
                getOrderData(orderId,email);
            }
        }
    });
}


exports.handler = (data, context, callback) => {
    let obj = data.body;
    let appname = '';
    console.log('\n headers : ');
    let headers = data.headers;
    console.log(headers);
    try{
        appname = headers["x-appname"];
    }
    catch{
        appname = undefined;
        console.log(err);
    }

    //checking for appname header
    if(appname == undefined){
        eventBus.emit('err',{error:true,headerError:'missing x-appname'});
    }else{
        let orderId = JSON.parse(data.body).orderId;
        let email = JSON.parse(data.body).email;
        console.log("\n orderId: \n" + orderId + '\n');
        getAppData(appname,orderId,email?email:'');
    }
   
    eventBus.on('success', () => {
        callback(null, { statusCode: 200, body: JSON.stringify({error:false, message: 'mail sent sucessfully' }) });
    });

    eventBus.on('err', (err) => {
        callback(null, { statusCode: 200, body: JSON.stringify(err) });
    });
};