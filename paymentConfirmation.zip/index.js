const AWS = require("aws-sdk");
const DynamoDB = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1', apiVersion: '2012-08-10' });
const template = require('./template.json');
console.log(template);
const events = require('events');

var eventBus = new events.EventEmitter();

// AWS.config.loadFromPath('./config.json');

function getOrderData(referenceId){
    console.log('\nlog from getOrderData\n');
    let params = {
        TableName: "square_payments",
        KeyConditionExpression: "#orderId = :orderId",
        ExpressionAttributeNames: {
            "#orderId": "orderId"
        },
        ExpressionAttributeValues: {
            ":orderId": referenceId
        }
    }
    DynamoDB.query(params, (err, data) => {
        if (err) {
            console.log('\n db error:' + JSON.stringify(err) + '\n');
        } else {
            console.log('\n email:' + data.Items[0].email + '\n');
            console.log(data.Items[0].line_items);
            sendEmailNotification(data.Items[0].email,data.Items[0].name,data.Items[0].line_items);
        }
    });
}

function sendEmailNotification(mail,name,items){
    console.log('\nlog from sendEmailNotification\n');
    var html = template.header +template.greetings +name +template.body;
    for(i = 0;i < items.length;i++){
        html += template.card_title + items[i].name + template.card_price + items[i].base_price_money.amount + template.card_quantity + items[i].quantity + template.card_end;
    } 
    html += template.footer;
    let params = {
        Destination:{
            ToAddresses:[mail]
        },
        Message:{
            Body:{
                Html:{
                    Charset:"UTF-8",
                    Data:html
                }
            },
            Subject:{
                Charset:"UTF-8",
                Data:"Test mail"
            }
        },
        Source: "Payment Confirmation <dlamb@bellcoww.com>"
    };
    let sendMailPromise = new AWS.SES({apiVersion:'2010-12-01'}).sendEmail(params).promise();
    sendMailPromise.then((data)=>{
        console.log('\nemail data:' + data+'\n');
        eventBus.emit('success');
    }).catch((err)=>{
        console.log('\nemail error:' + err +'\n');
    });
}


exports.handler = (data, context, callback) => {
    let obj = data.body;
    let orderId = JSON.parse(data.body).orderId;
    console.log("\n orderId: \n" + orderId + '\n');
    getOrderData(orderId);
    eventBus.on('success',()=>{
        callback(null,{statusCode:200,body: JSON.stringify({message:'mail sent sucessfully'})});
    });
};